# 🔭 Starlink-Insight

**Starlink-Insight** is a real-time satellite tracker that overlays Starlink positions with internet performance metrics (latency/speed) in remote regions.

## 🚀 Features

- Fetches and updates TLE data for Starlink
- Plots real-time satellite paths on a map
- Correlates satellite overhead times with internet speed test data
- Optional Flask dashboard for visual insights

## 📦 Tech Stack

- Python
- `skyfield`, `matplotlib`, `requests`, `flask` (optional)
- Starlink TLE data (from Celestrak or Space-Track)

## 📁 Run It

```bash
pip install -r requirements.txt
python app/tracker.py
python app/internet_analysis.py
```

To run the dashboard:

```bash
cd dashboard
python app.py
```

## 🌌 Why It’s Cool

Combines real-time astronomy with internet data to analyze how Starlink satellites impact connectivity—especially in underserved regions.

---
Made with 💫 for fellow space nerds.
